DROP TABLE boek_auteur;
DROP TABLE auteur;
DROP TABLE caddy_boek;
DROP TABLE boek;
DROP TABLE caddy;
DROP TABLE klant CASCADE CONSTRAINTS;
DROP TABLE gemeente CASCADE CONSTRAINTS;


DROP SEQUENCE caddy_caddyid_seq;
DROP SEQUENCE klant_klantnr_seq;
DROP SEQUENCE auteur_auteurnr_seq;

CREATE TABLE gemeente (
gemeente VARCHAR2(25) CONSTRAINT gemeente_gemeente_pk PRIMARY KEY,
postcode NUMBER(4)
);

CREATE TABLE klant (
klantnr NUMBER(6) CONSTRAINT klant_klantnr_pk PRIMARY KEY,
paswoord VARCHAR2(15),
achternaam VARCHAR2(20),
voornaam VARCHAR2(20),
straat VARCHAR2(30),
huisnr VARCHAR2(8),
gemeente VARCHAR2(25) CONSTRAINT klant_gemeente_fk REFERENCES gemeente (gemeente),
email VARCHAR2(30) CONSTRAINT klant_email_uk UNIQUE
);

CREATE TABLE caddy (
caddy_id NUMBER(4) CONSTRAINT caddy_caddyid_pk PRIMARY KEY,
datum DATE,
verzendkosten NUMBER(4,2),
klant_id NUMBER(6) CONSTRAINT caddy_klantid_fk REFERENCES klant (klantnr)
);

CREATE TABLE boek (
ISBN NUMBER(10) CONSTRAINT boek_isbn_pk PRIMARY KEY,
titel VARCHAR2(60),
prijs NUMBER(6,2)
);

CREATE TABLE caddy_boek (
caddy_id NUMBER(4) CONSTRAINT caddyboek_caddyid_fk REFERENCES caddy (caddy_id),
ISBN NUMBER(10) CONSTRAINT boek_isbn_fk REFERENCES boek (isbn),
aantal NUMBER(3),
CONSTRAINT cadboek_cadid_isbn_pk PRIMARY KEY (caddy_id, isbn)
);

CREATE TABLE auteur (
auteurnr NUMBER(5) CONSTRAINT auteur_auteurnr_pk PRIMARY KEY,
voornaam VARCHAR2(20),
achternaam VARCHAR2(20)
);

CREATE TABLE boek_auteur (
ISBN NUMBER(10) CONSTRAINT boekauteur_isbn_fk REFERENCES boek (isbn),
auteur_id NUMBER(5) CONSTRAINT boekauteur_auteurid_fk REFERENCES auteur (auteurnr),
CONSTRAINT boekauteur_isbnauteurid_pk PRIMARY KEY (isbn, auteur_id)
);


CREATE SEQUENCE caddy_caddyid_seq;
CREATE SEQUENCE klant_klantnr_seq;
CREATE SEQUENCE auteur_auteurnr_seq;


INSERT INTO gemeente VALUES ('Brugge',8000);

INSERT INTO gemeente VALUES ('Namen', 5000);

INSERT INTO gemeente VALUES ('Charleroi', 6000);

INSERT INTO gemeente VALUES ('Waver', 1300);

INSERT INTO gemeente VALUES ('Genk', 3600);

INSERT INTO gemeente VALUES ('Bree', 3960);

INSERT INTO gemeente VALUES ('Diepenbeek', 3590);

INSERT INTO gemeente VALUES ('Aalst', 9300);

INSERT INTO gemeente VALUES ('Aalter', 9880);

INSERT INTO gemeente VALUES ('Aarlen', 6700);

INSERT INTO gemeente VALUES ('Aarschot', 3200);

INSERT INTO gemeente VALUES ('Aartselaar', 2630);

INSERT INTO gemeente VALUES ('Affligem', 1790);

INSERT INTO gemeente VALUES ('Antwerpen', 2000);

INSERT INTO gemeente VALUES ('Balen', 2490);

INSERT INTO gemeente VALUES ('Bastogne', 6600);

INSERT INTO gemeente VALUES ('Beernem', 8730);

INSERT INTO gemeente VALUES ('Beerse', 2340);

INSERT INTO gemeente VALUES ('Beersel', 1650);

INSERT INTO gemeente VALUES ('Bekkevoort', 3460);

INSERT INTO gemeente VALUES ('Bergen', 7000);

INSERT INTO gemeente VALUES ('Bierbeek', 3360);

INSERT INTO gemeente VALUES ('Borgworm', 4300);

INSERT INTO gemeente VALUES ('Brussel', 1000);

INSERT INTO gemeente VALUES ('Chimay', 6460);

INSERT INTO gemeente VALUES ('Chiny', 6810);

INSERT INTO gemeente VALUES ('Celles', 7760);

INSERT INTO gemeente VALUES ('Damme', 8340);

INSERT INTO gemeente VALUES ('Deinze', 9800);

INSERT INTO gemeente VALUES ('Dendermonde', 9200);

INSERT INTO gemeente VALUES ('Doornik', 7500);

INSERT INTO gemeente VALUES ('Eeklo', 9900);

INSERT INTO gemeente VALUES ('Edegem',2650);

INSERT INTO gemeente VALUES ('Erpe-Mere', 9420);

INSERT INTO gemeente VALUES ('Erps-Kwerps', 3071);

INSERT INTO gemeente VALUES ('Evere', 1140);

INSERT INTO gemeente VALUES ('Elsene', 1050);

INSERT INTO gemeente VALUES ('Faimes', 4317);

INSERT INTO gemeente VALUES ('Fernelmont',5380);

INSERT INTO gemeente VALUES ('Forrest', 1190);

INSERT INTO gemeente VALUES ('Geel', 2440);

INSERT INTO gemeente VALUES ('Geetbets',3450);

INSERT INTO gemeente VALUES ('Gistel',8470);

INSERT INTO gemeente VALUES ('Grobbendonk',2280);

INSERT INTO gemeente VALUES ('Haacht',3150);

INSERT INTO gemeente VALUES ('Hasselt',3500);

INSERT INTO gemeente VALUES ('Zolder',3550);

INSERT INTO gemeente VALUES ('Heusden',3550);

INSERT INTO gemeente VALUES ('Heers',3870);

INSERT INTO gemeente VALUES ('Hoegaarden',3320);

INSERT INTO gemeente VALUES ('Houthalen',3530);

INSERT INTO gemeente VALUES ('Helchteren',3530);

INSERT INTO gemeente VALUES ('Ieper',8900);

INSERT INTO gemeente VALUES ('Izegem',8870);

INSERT INTO gemeente VALUES ('Jabbeke',8490);

INSERT INTO gemeente VALUES ('Jette',1090);

INSERT INTO gemeente VALUES ('Kampenhout',1910);

INSERT INTO gemeente VALUES ('Koekelare',8680);

INSERT INTO gemeente VALUES ('Leuven',3000);

INSERT INTO gemeente VALUES ('Lommel',3920);

INSERT INTO gemeente VALUES ('Maaseik',3680);

INSERT INTO gemeente VALUES ('Meensel',3391);

INSERT INTO gemeente VALUES ('Kiezegem',3391);

INSERT INTO gemeente VALUES ('Nijvel',1400);

INSERT INTO gemeente VALUES ('Ohey',5350);

INSERT INTO gemeente VALUES ('Opglabbeek',3660);

INSERT INTO gemeente VALUES ('Overpelt',3900);

INSERT INTO gemeente VALUES ('Peer',3990);

INSERT INTO gemeente VALUES ('Retie',2470);

INSERT INTO gemeente VALUES ('Ronse',9600);

INSERT INTO gemeente VALUES ('Scherpenheuvel',3270);

INSERT INTO gemeente VALUES ('Tielt',3390);

INSERT INTO gemeente VALUES ('Winge',3390);

INSERT INTO gemeente VALUES ('Tienen',3300);

INSERT INTO gemeente VALUES ('Ukkel',1180);

INSERT INTO gemeente VALUES ('Verviers',4800);

INSERT INTO gemeente VALUES ('Veurne',8630);

INSERT INTO gemeente VALUES ('Voeren',3790);

INSERT INTO gemeente VALUES ('Westerlo',2260);

INSERT INTO gemeente VALUES ('Zaventem',1930);

INSERT INTO gemeente VALUES ('Zichem',3271);




INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'motrob', 'Motmans','Rob','Sint-Maartenplein',36,'Zaventem','rob.motmans@gmail.com');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'nielskla/', 'Klawitter','Nils','Zonneweeldelaan',17,'Peer','nils.klawitter@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jules10','Kenes','Jules','Statiestraat',74,'Tielt','juleskenes@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'fFons','Franssen','Fons','Saliestraat',76,'Tielt','fons.franssen@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'alihuis','Huisjes','Allibert','Bloemenstraat',76,'Hasselt','allibert.huisjes@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'bjwil','Willems','Bart','Vaarnstraat',25,'Hasselt','bart.willems@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'wwater','Waterman','Wannes','peertjesstraat',76,'Balen','wannes.waterman@gmail.com');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'herKJU','Janssens','Herbert','Tulpenstraat',76,'Beerse','herbert.janssens@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'klimpop','Klimop','Fine','Meesstraat',76,'Meensel','fine.klimop@base.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jefke20', 'Daenen','Jef','Jaagpad',2,'Kiezegem','jef.daenen@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'luctik','Tilkens','Luciene','P.Ballingsstraat',76,'Zolder','luciene.tilkes@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'marclaes','Claes','Margaret','Kolenstraat',76,'Diepenbeek','margaret.claes@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jKup30','Kuppens','Johan','Madeliefstraat',62,'Diepenbeek','johan.kuppens@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'beertje30','Beervoets','Kris','Dorpsstraat',42,'Hasselt','kris.beervoets@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jber55','Berden','Johan','Blerebergstraat',22,'Antwerpen','johanberden@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'antje22*','Spaelt','Annelies','Grensstraat',45,'Gistel','annelies.spaelt@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'tvan11','Vanneste','Truus','Lievensstraat',12,'Jabbeke','truus.vanneste@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'vindgoed','Goedeman','Vincent','Kerkstraat',62,'Hasselt','vincentgoedeman@gmail.com');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'verstreek11','Verstreken','John','Koelstraat',65,'Heusden','john.verstreken@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jaja9090','Janssens','Janina','Tuinstraat',98,'Zolder','janina.janssens@base.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'pietje00','Heersel','Piet','Watermanstraat',48,'Beernem','pietheersel@base.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'tibo', 'Borders','Tim','Dorpsstraat',62,'Zolder','tim.borders@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'stevter','Terriers','Steven','Sporkstraat',65,'Houthalen','steven.terriers@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'sventeer22/','Teerain','Sven','Sportstraat',62,'Helchteren','sven.teerain@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'bergjes66','Bergen','Koen','Landweg',69,'Hasselt','koen.bergen@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'berber2020','Bertels','Bert','Koekoeksstraat',62,'Geel','bert.bertels@base.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'bebe125','De Backer','Birgit','Merelstraat',62,'Balen','birgit.debacker@politie.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jchan', 'Charlo','Jan','Veldstraat',22,'Geel','jan.charlo@gmail.com');



INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'Joepie1', 'Stoemp', 'Jan', 'Bloemenstraat', 36, 'Zolder', 'jan.stoemp@gmail.be');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jurioe25*', 'Vesters', 'Chris', 'Doelenlaan', '25 bus 5', 'Grobbendonk', 'chris.vesters@gmail.com');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'polpol54', 'Paulussen', 'Marnix', 'Petruslaan', 58, 'Houthalen', 'marnix.paulussen@outlook.com');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'triestig', 'Ollebolle', 'Nele', 'Papaverstraat', 54, 'Helchteren', 'nele.ollebolle@base.be');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'heroes58', 'Calassen', 'Truus', 'Ballenstraat', 25, 'Heusden', 'truusje@gmail.com');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'bruintje66', 'Grotten', 'Gerben', 'Geraniumstraat', 587, 'Hasselt', 'gerbengrotten@outlook.com');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'mjuioj87/', 'Nresus', 'Siebren', 'Pradkanstraat', 87, 'Lommel', 'Siebren.nresus@outlook.com');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'eifojhlqs', 'Brillemans', 'Stan', 'Tieltsebaan', 54, 'Tielt', 'stan.brillemans@base.be');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'takkewijf65', 'Stoorzender', 'Cedric', 'Neersebaan', '54 bus2', 'Haacht', 'cedric.stoorzender@outlook.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'motpiet', 'Motmans','Pieter','Sint-Maartenplein',36,'Zaventem','pieter.motmans@gmail.com');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'tomkla/', 'Klawitter','Tom','Zonneweeldelaan',17,'Peer','tom.klawitter@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jules10','Kenes','Jan','Statiestraat',74,'Tielt','jkenes@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'ffons','Franssen','Frans','Saliestraat',76,'Tielt','frans.franssen@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'alhuis','Huisjes','Albert','Bloemenstraat',76,'Hasselt','albert.huisjes@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'bjwil','Willems','Bjorn','Vaarnstraat',25,'Peer','bjorn.willems@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'wwater','Waterman','Wim','peertjesstraat',76,'Balen','wim.waterman@gmail.com');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'herKJU','Janssens','Herman','Tulpenstraat',76,'Beerse','h.janssens@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'Fklimpop','Klimop','Fien','Meesstraat',76,'Meensel','fien.klimop@base.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'joske20*', 'Daenen','Jozefien','Jaagpad',2,'Kiezegem','jozefien.daenen@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'lucietik','Tilkens','Lucie','P.Ballingsstraat',76,'Zolder','lucie.tilkes@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'martinclaes','Claes','Martin','Kolenstraat',76,'Diepenbeek','martin.claes@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jkus30','Kuskes','Johan','Madeliefstraat',62,'Diepenbeek','johan.kuskes@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'beertje30','Bervoets','Jan','Dorpsstraat',42,'Hasselt','jan.bervoets@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jber55','Berden','Johan','Blerebergstraat',22,'Tielt','johan.berden@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'antje22*','Turelure','Annelies','Grensstraat',45,'Gistel','annelies.turelure@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'tvan11','Vanneste','Tim','Lievensstraat',12,'Jabbeke','tim.vanneste@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'vindgoed','Goedeman','Vincent','Kappelstraat',62,'Heusden','vincent.goedeman@gmail.com');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'verstreek11','Verstreeks','John','Koelstraat',65,'Heusden','john.verstreeks@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jaja9090','Jans','Janina','Tuinstraat',98,'Zolder','janina.jans@base.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'pietje00','Heersel','Piet','Watermanstraat',48,'Beernem','piet.heersel@base.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'tibooo', 'Borders','Timothy','Dorpsstraat',62,'Zolder','timothy.borders@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'stevter','Terriers','Stef','Sporkstraat',65,'Houthalen','stef.terriers@telenet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'sventer22/','Terain','Sven','Sportstraat',62,'Helchteren','sven.terain@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'bergjes6','Bergens','Koen','Landweg',69,'Hasselt','koen.bergens@skynet.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'berber20','Berteleers','Bert','Koekoeksstraat',62,'Geel','bert.berteleers@base.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'bebee125','De Backer','Brigit','Merelstraat',62,'Balen','brigit.debacker@politie.be');

INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jchan', 'Charloo','Jan','Veldstraat',22,'Gistel','jan.charloo@gmail.com');



INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'Joepie1', 'Stoemp', 'Janie', 'Bloemenstraat', 36, 'Zolder', 'janie.stoemp@gmail.be');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'jurioe25*', 'Vesters', 'Joerie', 'Doelenlaan', '25 bus 5', 'Grobbendonk', 'joerie.vesters@gmail.com');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'piepol54', 'Paulussen', 'pieter', 'Petruslaan', 58, 'Houthalen', 'pieter.paulussen@outlook.com');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'triestig', 'Ollebolle', 'Nel', 'Papaverstraat', 54, 'Helchteren', 'nel.ollebolle@base.be');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'heroes58', 'Calassen', 'Truus', 'Ballenstraat', 185, 'Houthalen', 'truusje.calassen@gmail.com');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'bruintje66', 'Grotten', 'Arthuur', 'Geraniumstraat', 587, 'Hasselt', 'agrotten@outlook.com');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'mjuioj87/', 'Nresus', 'Siebren', 'Pradkanstraat', 87, 'Lommel', 'Siebrennresus@outlook.com');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'eifojhlqs', 'Brillemans', 'Mitchel', 'Tieltsebaan', 54, 'Tielt', 'brillemans@base.be');
INSERT INTO klant VALUES(klant_klantnr_seq.NEXTVAL,'takkewijf65', 'Stoorzender', 'Kevin', 'Neersebaan', '54 bus2', 'Haacht', 'kevin.stoorzender@outlook.be');




INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Aag', 'Vernelen');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'An', 'Candaele');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Ann', 'Driessen');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Anna', 'Luyten');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Anne', 'Provoost');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Bart', 'Koubaa');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Wouter', 'Kersbergen');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Yella', 'Arnauts');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Wim', 'Geysen');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Veronique', 'Marien');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Wally', 'De Doncker');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Veerle', 'Derave');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Toon', 'Hillewaere');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Trui', 'Chielens');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Tom', 'Schamp');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Tine', 'Mortier');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Toni', 'Coppens');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Sven', 'Cooremans');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Suzanne', 'Binnemans');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Tania', 'Dylgat');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Staf', 'Schoeters');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Stefan', 'Boonen');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Stefaan', 'Tops');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Rudolf', 'Hecke');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Silvie', 'Moors');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Sine', 'Van Mol');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Ruth', 'Lasters');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Soetkine', 'Aps');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Serge', 'Baeken');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Henning', 'Mankel');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Rudi', 'Hermans');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Ron', 'Langenus');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Roland', 'Jooris');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Rik', 'van Daele');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Riet', 'Vanloo');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Roger', 'De Neef');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Pol', 'Hoste');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Renaat', 'Ramon');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Reina', 'Ollivier');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Pieter', 'Serrien');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Reinout', 'Verbeke');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Piet', 'Thomas');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Peter', 'Verhelst');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Peter', 'Terrin');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Paul', 'Verrept');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Peter', 'Henderix');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Pat', 'van Beirs');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Patricia', 'David');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Nils', 'Pieters');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Nick', 'Meynen');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Patrick', 'Bernauw');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Mieke', 'Vanpol');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Mieke', 'Versyp');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Mattias', 'De Leeuuw');
INSERT INTO auteur VALUES (auteur_auteurnr_seq.NEXTVAL, 'Matthijs', 'de Ridder');


INSERT INTO boek VALUES (1450002147, 'Fifth Mystery', 9.99);
INSERT INTO boek VALUES (1450058741, 'One Step Behind', 9.99);
INSERT INTO boek VALUES (1450069874, 'An Event in Autumn', 9.99);
INSERT INTO boek VALUES (1450058963, 'The Dogs of Riga', 9.99);
INSERT INTO boek VALUES (1450025874, 'Studies on Copular Sentences', 9.99);
INSERT INTO boek VALUES (1450023698, 'De terugkeer van de dansleraar', 9.99);
INSERT INTO boek VALUES (1450014785, 'Midzomermoord', 9.99);
INSERT INTO boek VALUES (1450024785, 'Het spookklooster', 17.50);
INSERT INTO boek VALUES (1450025412, 'De Chinees', 10);
INSERT INTO boek VALUES (1450096336, 'Trein 16.50', 14.99);
INSERT INTO boek VALUES (1450058558, 'Labyrint', 9.99);
INSERT INTO boek VALUES (1450058521, 'Terroristenjager', 19.99);
INSERT INTO boek VALUES (1450014441, 'De monogram moorden', 19.95);
INSERT INTO boek VALUES (1450045454, 'De Cock en de dode diva', 9.99);
INSERT INTO boek VALUES (1450044478, 'Onvoltooide zomer', 9.99);
INSERT INTO boek VALUES (1451458700, 'De kille maagd', 15);
INSERT INTO boek VALUES (1450145870, 'Geen veilige plek', 19.99);
INSERT INTO boek VALUES (1450011214, 'Het rechte pad', 15);
INSERT INTO boek VALUES (1450125870, 'een beetje meer naar rechts', 10);
INSERT INTO boek VALUES (1450025896, 'Witse - Operatie solar', 16.50);
INSERT INTO boek VALUES (1450022587, 'Stille blik', 7);
INSERT INTO boek VALUES (1450032145, 'Valse vrindinnen', 34.95);
INSERT INTO boek VALUES (1345002587, 'Schemeruur', 4.95);
INSERT INTO boek VALUES (1345002145, 'Laatste goede man', 12.50);
INSERT INTO boek VALUES (1345007414, 'Het testament van Nostradamus', 22.95);
INSERT INTO boek VALUES (1345004478, 'Onderstroom', 20.55);
INSERT INTO boek VALUES (1345006985, 'Springtij', 16.95);
INSERT INTO boek VALUES (1345006547, 'De stilte na Sarah', 18.90);
INSERT INTO boek VALUES (1345002314, 'Een onafwendbaar einde', 28.95);
INSERT INTO boek VALUES (1345005412, 'De onzichtbare echtgenote', 19.90);
INSERT INTO boek VALUES (1345001254, 'Een kuil voor een ander', 9.95);
INSERT INTO boek VALUES (1345008874, 'Vogelman', 22.50);
INSERT INTO boek VALUES (1345001145, 'Rood water', 15.98);
INSERT INTO boek VALUES (1345008854, 'De hoeders van het verbond', 9.90);
INSERT INTO boek VALUES (1345002582, 'De man zonder hond', 28.90);
INSERT INTO boek VALUES (1345001547, 'De zaak van Munster', 9.90);
INSERT INTO boek VALUES (1345006566, 'Het evangelie van Lucifer', 15);
INSERT INTO boek VALUES (1345005541, 'Drie seconden', 12.50);
INSERT INTO boek VALUES (2645001254, 'Grafheuvel', 21.95);
INSERT INTO boek VALUES (2645001253, 'Londengrad', 19.90);
INSERT INTO boek VALUES (2645001252, 'Misdaad in Marseille', 29.90);
INSERT INTO boek VALUES (2645001251, 'Het ABC-mysterie', 12.50);
INSERT INTO boek VALUES (2645001250, 'Moord op de Nijl', 12.50);
INSERT INTO boek VALUES (2645001255, 'Verdwijningen', 3.99);
INSERT INTO boek VALUES (2645001256, 'Midsomer Murders', 24.90);
INSERT INTO boek VALUES (2645001257, 'Slapers', 11.90);
INSERT INTO boek VALUES (2645001258, 'Moord aan tafel', 12.50 );
INSERT INTO boek VALUES (2645001259, 'Een licht in de duisternis', 5.00);
INSERT INTO boek VALUES (2645001260, 'Engel van de stad', 19.95);
INSERT INTO boek VALUES (2645001261, 'Buzz', 17.50);
INSERT INTO boek VALUES (2645001262, 'Misteriosa', 19.95);
INSERT INTO boek VALUES (2645001263, 'Het meisje in de trein', 19.95);
INSERT INTO boek VALUES (2645001264, 'Mooie meisjes', 22.90);
INSERT INTO boek VALUES (2645001265, 'Denken aan vrijdag', 19.99);
INSERT INTO boek VALUES (2645001266, 'De rode kamer', 19.99);
INSERT INTO boek VALUES (2645001267, 'De eerlijke vinder',19.99);
INSERT INTO boek VALUES (2645001268, 'Bericht uit Parijs', 4.95);
INSERT INTO boek VALUES (2645001269, 'Lieve mama', 19.95);
INSERT INTO boek VALUES (2645001270, 'Game of Thrones - Het spel der tronen', 19.95);
INSERT INTO boek VALUES (2645001271, 'Meisje vermist', 19.99);
INSERT INTO boek VALUES (2645001272, 'De doos', 21.99);
INSERT INTO boek VALUES (2645001273, 'Ik ben pelgrim', 17.50);
INSERT INTO boek VALUES (2645001274, 'De grenzeloze', 17.50);
INSERT INTO boek VALUES (2645001275, 'Doodsimpel', 21.99);
INSERT INTO boek VALUES (2645001276, 'Viva Espana', 5.00);
INSERT INTO boek VALUES (2645001277, 'De geheugenman', 19.95);
INSERT INTO boek VALUES (2645001278, 'Het stille graf', 5.95);
INSERT INTO boek VALUES (2645001279, 'Blauwe maandag', 8.99);
INSERT INTO boek VALUES (2645001280, 'De ontsnapping', 15);
INSERT INTO boek VALUES (2645001281, 'Stalker', 19.90);
INSERT INTO boek VALUES (2645001282, 'Over de schreef', 19.99);
INSERT INTO boek VALUES (2645001283, 'Game of Thrones - De strijd der koningen', 19.95);
INSERT INTO boek VALUES (2645001284, 'Over de schreef', 19.99);
INSERT INTO boek VALUES (2645001285, 'Mars', 12.95);
INSERT INTO boek VALUES (3745001201, 'De fazantenmoordenaars', 12.95);
INSERT INTO boek VALUES (3745001202, 'De fantasten', 9.99);


INSERT INTO boek_auteur VALUES (1450002147, 03);
INSERT INTO boek_auteur VALUES (1450058741, 16);
INSERT INTO boek_auteur VALUES (1450069874, 23);
INSERT INTO boek_auteur VALUES (1450058963, 55);
INSERT INTO boek_auteur VALUES (1450025874, 25);
INSERT INTO boek_auteur VALUES (1450023698, 14);
INSERT INTO boek_auteur VALUES (1450014785, 47);
INSERT INTO boek_auteur VALUES (1450024785, 38);
INSERT INTO boek_auteur VALUES (1450025412, 41);
INSERT INTO boek_auteur VALUES (1450096336, 39);
INSERT INTO boek_auteur VALUES (1450058558, 29);
INSERT INTO boek_auteur VALUES (1450058521, 31);
INSERT INTO boek_auteur VALUES (1450014441, 35);
INSERT INTO boek_auteur VALUES (1450045454, 33);
INSERT INTO boek_auteur VALUES (1450044478, 36);
INSERT INTO boek_auteur VALUES (1451458700, 19);
INSERT INTO boek_auteur VALUES (1450145870, 11);
INSERT INTO boek_auteur VALUES (1450011214, 15);
INSERT INTO boek_auteur VALUES (1450125870, 10);
INSERT INTO boek_auteur VALUES (1450025896, 50);
INSERT INTO boek_auteur VALUES (1450022587, 07);
INSERT INTO boek_auteur VALUES (1450032145, 25);
INSERT INTO boek_auteur VALUES (1345002587, 31);
INSERT INTO boek_auteur VALUES (1345002145, 12);
INSERT INTO boek_auteur VALUES (1345007414, 08);
INSERT INTO boek_auteur VALUES (1345004478, 18);
INSERT INTO boek_auteur VALUES (1345006985, 49);
INSERT INTO boek_auteur VALUES (1345006547, 43);
INSERT INTO boek_auteur VALUES (1345002314, 33);
INSERT INTO boek_auteur VALUES (1345005412, 21);
INSERT INTO boek_auteur VALUES (1345001254, 44);
INSERT INTO boek_auteur VALUES (1345008874, 27);
INSERT INTO boek_auteur VALUES (1345001145, 04);
INSERT INTO boek_auteur VALUES (1345008854, 52);
INSERT INTO boek_auteur VALUES (1345002582, 37);
INSERT INTO boek_auteur VALUES (1345001547, 34);
INSERT INTO boek_auteur VALUES (1345006566, 53);
INSERT INTO boek_auteur VALUES (1345005541, 40);
INSERT INTO boek_auteur VALUES (2645001254, 36);
INSERT INTO boek_auteur VALUES (2645001253, 12);
INSERT INTO boek_auteur VALUES (2645001252, 03);
INSERT INTO boek_auteur VALUES (2645001251, 06);
INSERT INTO boek_auteur VALUES (2645001250, 21);
INSERT INTO boek_auteur VALUES (2645001255, 26);
INSERT INTO boek_auteur VALUES (2645001256, 25);
INSERT INTO boek_auteur VALUES (2645001257, 29);
INSERT INTO boek_auteur VALUES (2645001258, 30);
INSERT INTO boek_auteur VALUES (2645001259, 19);
INSERT INTO boek_auteur VALUES (2645001260, 23);
INSERT INTO boek_auteur VALUES (2645001261, 31);
INSERT INTO boek_auteur VALUES (2645001262, 49);
INSERT INTO boek_auteur VALUES (2645001263, 44);
INSERT INTO boek_auteur VALUES (2645001264, 42);
INSERT INTO boek_auteur VALUES (2645001265, 39);
INSERT INTO boek_auteur VALUES (2645001266, 49);
INSERT INTO boek_auteur VALUES (2645001267, 13);
INSERT INTO boek_auteur VALUES (2645001268, 24);
INSERT INTO boek_auteur VALUES (2645001269, 38);
INSERT INTO boek_auteur VALUES (2645001270, 42);
INSERT INTO boek_auteur VALUES (2645001271, 16);
INSERT INTO boek_auteur VALUES (2645001272, 26);
INSERT INTO boek_auteur VALUES (2645001273, 36);
INSERT INTO boek_auteur VALUES (2645001274, 46);
INSERT INTO boek_auteur VALUES (2645001275, 55);
INSERT INTO boek_auteur VALUES (2645001276, 46);
INSERT INTO boek_auteur VALUES (2645001277, 32);
INSERT INTO boek_auteur VALUES (2645001278, 44);
INSERT INTO boek_auteur VALUES (2645001279, 33);
INSERT INTO boek_auteur VALUES (2645001280, 22);
INSERT INTO boek_auteur VALUES (2645001281, 28);
INSERT INTO boek_auteur VALUES (2645001282, 26);
INSERT INTO boek_auteur VALUES (2645001283, 42);
INSERT INTO boek_auteur VALUES (2645001284, 12);
INSERT INTO boek_auteur VALUES (2645001285, 05);
INSERT INTO boek_auteur VALUES (3745001201, 15);
INSERT INTO boek_auteur VALUES (3745001202, 42);

INSERT INTO boek_auteur VALUES (1451458700, 20);
INSERT INTO boek_auteur VALUES (1450145870, 12);
INSERT INTO boek_auteur VALUES (1450011214, 16);
INSERT INTO boek_auteur VALUES (1450125870, 11);
INSERT INTO boek_auteur VALUES (1450025896, 52);
INSERT INTO boek_auteur VALUES (1450022587, 08);
INSERT INTO boek_auteur VALUES (1450032145, 23);
INSERT INTO boek_auteur VALUES (1345002587, 35);
INSERT INTO boek_auteur VALUES (1345002145, 17);
INSERT INTO boek_auteur VALUES (1345007414, 04);
INSERT INTO boek_auteur VALUES (1345004478, 16);
INSERT INTO boek_auteur VALUES (1345006985, 48);


INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '02-MAR-16', 4.99, 04);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '02-MAR-16', 4.99, 03);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '03-MAR-16', 4.99, 02);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '02-MAR-16', 4.99, 01);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '03-MAR-16', 4.99, 08);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '02-MAR-16', 4.99, 07);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '03-MAR-16', 4.99, 06);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '02-MAR-16', 4.99, 05);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '02-MAR-16', 4.99, 09);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '04-MAR-16', 4.99, 10);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '04-MAR-16', 4.99, 12);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '05-MAR-16', 4.99, 14);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '06-MAR-16', 4.99, 16);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '07-MAR-16', 4.99, 18);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '08-MAR-16', 4.99, 11);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '08-MAR-16', 4.99, 13);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '09-MAR-16', 4.99, 15);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '09-MAR-16', 4.99, 17);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '10-MAR-16', 4.99, 19);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '11-MAR-16', 4.99, 20);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '12-MAR-16', 4.99, 21);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '12-MAR-16', 4.99, 23);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '12-MAR-16', 4.99, 25);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '11-MAR-16', 4.99, 27);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '11-MAR-16', 4.99, 29);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '13-MAR-16', 4.99, 21);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '13-MAR-16', 4.99, 22);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '14-MAR-16', 4.99, 24);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '14-MAR-16', 4.99, 26);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '15-MAR-16', 4.99, 28);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '16-MAR-16', 4.99, 30);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '16-MAR-16', 4.99, 31);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '17-MAR-16', 4.99, 33);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '17-MAR-16', 4.99, 35);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '17-MAR-16', 4.99, 37);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '18-MAR-16', 4.99, 39);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '19-MAR-16', 4.99, 32);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '19-MAR-16', 4.99, 34);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '20-MAR-16', 4.99, 36);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '21-MAR-16', 4.99, 38);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '22-MAR-16', 4.99, 40);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '23-MAR-16', 4.99, 41);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '22-MAR-16', 4.99, 43);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '23-MAR-16', 4.99, 45);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '23-MAR-16', 4.99, 47);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '23-MAR-16', 4.99, 49);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '24-MAR-16', 4.99, 42);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '25-MAR-16', 4.99, 44);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '26-MAR-16', 4.99, 46);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '27-MAR-16', 4.99, 48);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '28-MAR-16', 4.99, 50);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '28-MAR-16', 4.99, 51);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '29-MAR-16', 4.99, 52);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '29-MAR-16', 4.99, 53);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '29-MAR-16', 4.99, 54);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '30-MAR-16', 4.99, 55);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '30-MAR-16', 4.99, 56);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '30-MAR-16', 4.99, 50);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '31-MAR-16', 4.99, 58);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '31-MAR-16', 4.99, 57);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '31-MAR-16', 4.99, 59);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '01-APR-16', 4.99, 60);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '01-APR-16', 4.99, 61);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '02-APR-16', 4.99, 63);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '02-APR-16', 4.99, 65);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '03-APR-16', 4.99, 67);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '04-APR-16', 4.99, 69);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '05-APR-16', 4.99, 62);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '06-APR-16', 4.99, 64);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '06-APR-16', 4.99, 66);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '07-APR-16', 4.99, 68);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '07-APR-16', 4.99, 70);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '07-APR-16', 4.99, 71);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '07-APR-16', 4.99, 73);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '08-APR-16', 4.99, 72);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '09-APR-16', 4.99, 73);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '10-APR-16', 4.99, 71);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '07-APR-16', 4.99, 72);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '07-APR-16', 4.99, 74);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '07-APR-16', 4.99, 74);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '10-APR-16', 4.99, 07);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '11-APR-16', 4.99, 06);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '12-APR-16', 4.99, 05);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '12-APR-16', 4.99, 09);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '14-APR-16', 4.99, 10);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '16-APR-16', 4.99, 12);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '17-APR-16', 4.99, 14);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '18-APR-16', 4.99, 16);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '18-APR-16', 4.99, 18);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '19-APR-16', 4.99, 11);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '20-APR-16', 4.99, 13);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '21-APR-16', 4.99, 15);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '22-APR-16', 4.99, 17);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '23-APR-16', 4.99, 27);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '24-APR-16', 4.99, 29);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '25-APR-16', 4.99, 21);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '26-APR-16', 4.99, 22);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '26-APR-16', 4.99, 24);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '27-APR-16', 4.99, 26);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '28-APR-16', 4.99, 28);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '29-APR-16', 4.99, 30);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '30-APR-16', 4.99, 31);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '01-MAY-16', 4.99, 33);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '02-MAY-16', 4.99, 35);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '02-MAY-16', 4.99, 37);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '03-MAY-16', 4.99, 39);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '03-MAY-16', 4.99, 32);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '04-MAY-16', 4.99, 34);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '05-MAY-16', 4.99, 36);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '06-MAY-16', 4.99, 38);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '07-MAY-16', 4.99, 67);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '08-MAY-16', 4.99, 69);
INSERT INTO caddy VALUES (caddy_caddyid_seq.NEXTVAL, '09-MAY-16', 4.99, 62);





INSERT INTO caddy_boek VALUES (0001, 1450002147, 1);
INSERT INTO caddy_boek VALUES (0001, 1450058741, 1);
INSERT INTO caddy_boek VALUES (0002, 1450069874, 2);
INSERT INTO caddy_boek VALUES (0002, 1450058963, 1);
INSERT INTO caddy_boek VALUES (0003, 1450025874, 1);
INSERT INTO caddy_boek VALUES (0004, 1450023698, 1);
INSERT INTO caddy_boek VALUES (0005, 1450014785, 1);
INSERT INTO caddy_boek VALUES (0005, 1450024785, 1);
INSERT INTO caddy_boek VALUES (0006, 1450025412, 1);
INSERT INTO caddy_boek VALUES (0007, 1450096336, 1);
INSERT INTO caddy_boek VALUES (0008, 1450058558, 1);
INSERT INTO caddy_boek VALUES (0008, 1450058521, 1);
INSERT INTO caddy_boek VALUES (0009, 1450014441, 3);
INSERT INTO caddy_boek VALUES (0009, 1450045454, 3);
INSERT INTO caddy_boek VALUES (0010, 1450044478, 1);
INSERT INTO caddy_boek VALUES (0010, 1451458700, 1);
INSERT INTO caddy_boek VALUES (0011, 1450145870, 1);
INSERT INTO caddy_boek VALUES (0011, 1450011214, 1);
INSERT INTO caddy_boek VALUES (0012, 1450125870, 1);
INSERT INTO caddy_boek VALUES (0012, 1450025896, 1);
INSERT INTO caddy_boek VALUES (0012, 1450022587, 1);
INSERT INTO caddy_boek VALUES (0013, 1450032145, 2);
INSERT INTO caddy_boek VALUES (0014, 1345002587, 1);
INSERT INTO caddy_boek VALUES (0015, 1345002145, 2);
INSERT INTO caddy_boek VALUES (0015, 1345007414, 1);
INSERT INTO caddy_boek VALUES (0016, 1345004478, 1);
INSERT INTO caddy_boek VALUES (0017, 1345006985, 1);
INSERT INTO caddy_boek VALUES (0018, 1345006547, 1);
INSERT INTO caddy_boek VALUES (0018, 1345002314, 1);
INSERT INTO caddy_boek VALUES (0019, 1345005412, 1);
INSERT INTO caddy_boek VALUES (0019, 1345001254, 2);
INSERT INTO caddy_boek VALUES (0020, 1345008874, 2);
INSERT INTO caddy_boek VALUES (0020, 1345001145, 1);
INSERT INTO caddy_boek VALUES (0021, 1345008854, 2);
INSERT INTO caddy_boek VALUES (0022, 1345002582, 1);
INSERT INTO caddy_boek VALUES (0023, 1345001547, 1);
INSERT INTO caddy_boek VALUES (0023, 1345006566, 1);
INSERT INTO caddy_boek VALUES (0024, 1345005541, 1);
INSERT INTO caddy_boek VALUES (0025, 2645001254, 1);
INSERT INTO caddy_boek VALUES (0026, 2645001253, 1);
INSERT INTO caddy_boek VALUES (0026, 2645001252, 1);
INSERT INTO caddy_boek VALUES (0027, 2645001251, 1);
INSERT INTO caddy_boek VALUES (0028, 2645001250, 1);
INSERT INTO caddy_boek VALUES (0029, 2645001255, 2);
INSERT INTO caddy_boek VALUES (0030, 2645001256, 2);
INSERT INTO caddy_boek VALUES (0031, 2645001257, 2);
INSERT INTO caddy_boek VALUES (0032, 2645001258, 1);
INSERT INTO caddy_boek VALUES (0033, 2645001259, 1);
INSERT INTO caddy_boek VALUES (0034, 2645001260, 2);
INSERT INTO caddy_boek VALUES (0034, 2645001261, 1);
INSERT INTO caddy_boek VALUES (0035, 2645001262, 1);
INSERT INTO caddy_boek VALUES (0036, 2645001263, 1);
INSERT INTO caddy_boek VALUES (0036, 2645001264, 2);
INSERT INTO caddy_boek VALUES (0037, 2645001265, 1);
INSERT INTO caddy_boek VALUES (0038, 2645001266, 1);
INSERT INTO caddy_boek VALUES (0039, 2645001267, 1);
INSERT INTO caddy_boek VALUES (0039, 2645001268, 2);
INSERT INTO caddy_boek VALUES (0039, 2645001269, 1);
INSERT INTO caddy_boek VALUES (0040, 2645001270, 2);
INSERT INTO caddy_boek VALUES (0041, 2645001271, 1);
INSERT INTO caddy_boek VALUES (0042, 2645001272, 2);
INSERT INTO caddy_boek VALUES (0043, 2645001273, 1);
INSERT INTO caddy_boek VALUES (0044, 2645001274, 1);
INSERT INTO caddy_boek VALUES (0044, 2645001275, 1);
INSERT INTO caddy_boek VALUES (0044, 2645001276, 1);
INSERT INTO caddy_boek VALUES (0045, 2645001277, 2);
INSERT INTO caddy_boek VALUES (0045, 2645001278, 4);
INSERT INTO caddy_boek VALUES (0046, 2645001279, 3);
INSERT INTO caddy_boek VALUES (0047, 2645001280, 2);
INSERT INTO caddy_boek VALUES (0048, 2645001281, 2);
INSERT INTO caddy_boek VALUES (0049, 2645001282, 2);
INSERT INTO caddy_boek VALUES (0050, 2645001283, 2);
INSERT INTO caddy_boek VALUES (0050, 2645001284, 1);
INSERT INTO caddy_boek VALUES (0051, 2645001285, 5);
INSERT INTO caddy_boek VALUES (0051, 3745001201, 1);
INSERT INTO caddy_boek VALUES (0052, 3745001202, 2);

INSERT INTO caddy_boek VALUES (0052, 1450002147, 1);
INSERT INTO caddy_boek VALUES (0053, 1450058741, 1);
INSERT INTO caddy_boek VALUES (0054, 1450069874, 2);
INSERT INTO caddy_boek VALUES (0054, 1450058963, 1);
INSERT INTO caddy_boek VALUES (0055, 1450025874, 1);
INSERT INTO caddy_boek VALUES (0056, 1450023698, 1);
INSERT INTO caddy_boek VALUES (0057, 1450014785, 1);
INSERT INTO caddy_boek VALUES (0058, 1450024785, 1);
INSERT INTO caddy_boek VALUES (0059, 1450025412, 1);
INSERT INTO caddy_boek VALUES (0059, 1450096336, 1);
INSERT INTO caddy_boek VALUES (0060, 1450058558, 1);
INSERT INTO caddy_boek VALUES (0060, 1450058521, 1);
INSERT INTO caddy_boek VALUES (0061, 1450014441, 3);
INSERT INTO caddy_boek VALUES (0061, 1450045454, 3);
INSERT INTO caddy_boek VALUES (0062, 1450044478, 1);
INSERT INTO caddy_boek VALUES (0062, 1451458700, 1);
INSERT INTO caddy_boek VALUES (0063, 1450145870, 1);
INSERT INTO caddy_boek VALUES (0064, 1450011214, 1);
INSERT INTO caddy_boek VALUES (0065, 1450125870, 1);
INSERT INTO caddy_boek VALUES (0066, 1450025896, 1);
INSERT INTO caddy_boek VALUES (0067, 1450022587, 1);
INSERT INTO caddy_boek VALUES (0068, 1450032145, 2);
INSERT INTO caddy_boek VALUES (0069, 1345002587, 1);
INSERT INTO caddy_boek VALUES (0070, 1345002145, 2);
INSERT INTO caddy_boek VALUES (0071, 1345007414, 1);
INSERT INTO caddy_boek VALUES (0071, 1345004478, 1);
INSERT INTO caddy_boek VALUES (0072, 1345006985, 1);
INSERT INTO caddy_boek VALUES (0072, 1345006547, 1);
INSERT INTO caddy_boek VALUES (0073, 1345002314, 1);
INSERT INTO caddy_boek VALUES (0073, 1345005412, 1);
INSERT INTO caddy_boek VALUES (0074, 1345001254, 2);
INSERT INTO caddy_boek VALUES (0075, 1345008874, 2);
INSERT INTO caddy_boek VALUES (0076, 1345001145, 1);
INSERT INTO caddy_boek VALUES (0077, 1345008854, 2);
INSERT INTO caddy_boek VALUES (0078, 1345002582, 1);
INSERT INTO caddy_boek VALUES (0079, 1345001547, 1);
INSERT INTO caddy_boek VALUES (0080, 1345006566, 1);
INSERT INTO caddy_boek VALUES (0081, 1345005541, 1);
INSERT INTO caddy_boek VALUES (0082, 2645001254, 1);
INSERT INTO caddy_boek VALUES (0082, 2645001253, 1);
INSERT INTO caddy_boek VALUES (0083, 2645001252, 1);
INSERT INTO caddy_boek VALUES (0084, 2645001251, 1);
INSERT INTO caddy_boek VALUES (0085, 2645001250, 1);
INSERT INTO caddy_boek VALUES (0086, 2645001255, 2);
INSERT INTO caddy_boek VALUES (0086, 2645001256, 2);
INSERT INTO caddy_boek VALUES (0087, 2645001257, 2);
INSERT INTO caddy_boek VALUES (0088, 2645001258, 1);
INSERT INTO caddy_boek VALUES (0089, 2645001259, 1);
INSERT INTO caddy_boek VALUES (0090, 2645001260, 2);
INSERT INTO caddy_boek VALUES (0091, 2645001261, 1);
INSERT INTO caddy_boek VALUES (0091, 2645001262, 1);
INSERT INTO caddy_boek VALUES (0092, 2645001263, 1);
INSERT INTO caddy_boek VALUES (0093, 2645001264, 2);
INSERT INTO caddy_boek VALUES (0094, 2645001265, 1);
INSERT INTO caddy_boek VALUES (0095, 2645001266, 1);
INSERT INTO caddy_boek VALUES (0096, 2645001267, 1);
INSERT INTO caddy_boek VALUES (0097, 2645001268, 2);
INSERT INTO caddy_boek VALUES (0098, 2645001269, 1);
INSERT INTO caddy_boek VALUES (0099, 2645001270, 2);
INSERT INTO caddy_boek VALUES (0100, 2645001271, 1);
INSERT INTO caddy_boek VALUES (0101, 2645001272, 2);
INSERT INTO caddy_boek VALUES (0102, 2645001273, 1);
INSERT INTO caddy_boek VALUES (0103, 2645001274, 1);
INSERT INTO caddy_boek VALUES (0104, 2645001275, 1);
INSERT INTO caddy_boek VALUES (0105, 2645001276, 1);
INSERT INTO caddy_boek VALUES (0106, 2645001277, 2);
INSERT INTO caddy_boek VALUES (0107, 2645001278, 4);
INSERT INTO caddy_boek VALUES (0108, 2645001279, 3);
INSERT INTO caddy_boek VALUES (0108, 2645001280, 2);
INSERT INTO caddy_boek VALUES (0109, 2645001281, 2);
INSERT INTO caddy_boek VALUES (0110, 2645001282, 2);
INSERT INTO caddy_boek VALUES (0111, 2645001283, 2);
INSERT INTO caddy_boek VALUES (0111, 2645001284, 1);
INSERT INTO caddy_boek VALUES (0112, 2645001285, 5);
INSERT INTO caddy_boek VALUES (0113, 3745001201, 1);
INSERT INTO caddy_boek VALUES (0113, 3745001202, 2);

commit;
