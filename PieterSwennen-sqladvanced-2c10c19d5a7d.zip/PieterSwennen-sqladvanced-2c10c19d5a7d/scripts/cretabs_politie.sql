drop table pv;
drop table personeel;
drop table salaris;
drop table graad;
drop table auto;
drop table type;
drop table overtredingen;
drop table departement;
drop table flitsen;
drop table gemeente;

DROP SEQUENCE DEPARTEMENT_ID_SEQ;   
DROP SEQUENCE FLITSEN_ID_SEQ;       
DROP SEQUENCE GRAAD_ID_SEQ;         
DROP SEQUENCE OVERTREDINGEN_ID_SEQ; 
DROP SEQUENCE PERSONEEL_ID_SEQ;     
DROP SEQUENCE PV_ID_SEQ;           
DROP SEQUENCE SALARIS_SALGRADE_SEQ;  

CREATE TABLE salaris (
  salgrade NUMBER(2),
  lsal NUMBER(5),
  hsal NUMBER(5),
  CONSTRAINT salaris_salgrade_pk PRIMARY KEY(salgrade)
);
CREATE TABLE type
(type VARCHAR2(25) CONSTRAINT type_type_pk PRIMARY KEY,
merk VARCHAR2(15)
);
CREATE TABLE auto
(kenteken VARCHAR2(8) CONSTRAINT auto_kenteken_pk PRIMARY KEY,
type VARCHAR2(25) CONSTRAINT auto_type_fk REFERENCES type (type),
bouwjaar NUMBER(4)
);
CREATE TABLE overtredingen (
  id NUMBER(2),
  naam VARCHAR2(30),
  geldboete NUMBER(5),
  gevangenis NUMBER(4),
  omschr VARCHAR2(150),
  CONSTRAINT overtredingen_id_pk PRIMARY KEY(id)
);
CREATE TABLE departement (
  id NUMBER(2),
  naam VARCHAR2(25),
  CONSTRAINT departement_id_pk PRIMARY KEY(id)
);
CREATE TABLE gemeente (
  postcode NUMBER(4),
  gemeente VARCHAR2(25),
  CONSTRAINT gemeente_postcode_pk PRIMARY KEY(postcode)
);
CREATE TABLE flitsen (
  id NUMBER(3),
  waar NUMBER(4),
  wanneer DATE,
  CONSTRAINT flitsen_id_pk PRIMARY KEY(id),  
  CONSTRAINT flitsen_waar_fk FOREIGN KEY(waar) REFERENCES gemeente(postcode)
);
CREATE TABLE graad (
  id NUMBER(2),
  functie VARCHAR2(35),
  CONSTRAINT graad_id_pk PRIMARY KEY(id)
);
CREATE TABLE personeel (
  id NUMBER(4),
  naam VARCHAR2(20),
  voornaam VARCHAR2(15),
  straat VARCHAR2(30),
  nr NUMBER(4),
  postcode NUMBER(4), 
  telnr VARCHAR2(12),
  gsmnr VARCHAR2(12),
  email VARCHAR2(40),
  kenteken VARCHAR2(8), 
  functie_id NUMBER(2), 
  deptnr NUMBER(2), 
  sal NUMBER(5), 
  indienst DATE,
  CONSTRAINT personeel_id_pk PRIMARY KEY(id),
  CONSTRAINT personeel_postcode_fk FOREIGN KEY(postcode) REFERENCES gemeente(postcode),
  CONSTRAINT personeel_kenteken_fk FOREIGN KEY(kenteken) REFERENCES auto(kenteken),
  CONSTRAINT personeel_functie_fk FOREIGN KEY(functie_id) REFERENCES graad(id),
  CONSTRAINT personeel_deptnr_fk FOREIGN KEY(deptnr) REFERENCES departement(id)
);
CREATE TABLE pv (
  id NUMBER(4),
  otnaam VARCHAR2(20),
  otvoornaam VARCHAR2(15),
  otstraat VARCHAR2(30),
  otnr NUMBER(4),
  otpostcode NUMBER(4),
  ottelnr VARCHAR2(12),
  personeelsnr NUMBER(3),
  otsoort_id NUMBER(2),
  datum DATE,
  tijd DATE,
  plaats NUMBER(4),
  uitleg VARCHAR2(150),
  CONSTRAINT pv_id_pk PRIMARY KEY(id),  
  CONSTRAINT pv_otpostcode_fk FOREIGN KEY(otpostcode) REFERENCES gemeente(postcode),
  CONSTRAINT pv_persnr_fk FOREIGN KEY(personeelsnr) REFERENCES personeel(id),
  CONSTRAINT pv_soort_fk FOREIGN KEY(otsoort_id) REFERENCES overtredingen(id),
  CONSTRAINT pv_plaats_fk FOREIGN KEY(plaats) REFERENCES gemeente(postcode)
);
CREATE SEQUENCE salaris_salgrade_seq
   MINVALUE 1 
   MAXVALUE 99 
   INCREMENT BY 1 
   START WITH 1
   NOCACHE 
   NOORDER 
   NOCYCLE;
CREATE SEQUENCE overtredingen_id_seq
   MINVALUE 1 
   MAXVALUE 99 
   INCREMENT BY 1 
   START WITH 1
   NOCACHE 
   NOORDER 
   NOCYCLE;
CREATE SEQUENCE flitsen_id_seq
   MINVALUE 1 
   MAXVALUE 999 
   INCREMENT BY 1 
   START WITH 1
   NOCACHE 
   NOORDER 
   NOCYCLE;
CREATE SEQUENCE graad_id_seq
   MINVALUE 1 
   MAXVALUE 99 
   INCREMENT BY 1 
   START WITH 1
   NOCACHE 
   NOORDER 
   NOCYCLE;
CREATE SEQUENCE departement_id_seq
   MINVALUE 1 
   MAXVALUE 99 
   INCREMENT BY 1 
   START WITH 1
   NOCACHE 
   NOORDER 
   NOCYCLE;
CREATE SEQUENCE personeel_id_seq
   MINVALUE 1 
   MAXVALUE 9999 
   INCREMENT BY 1 
   START WITH 1
   NOCACHE 
   NOORDER 
   NOCYCLE;
CREATE SEQUENCE pv_id_seq
   MINVALUE 1 
   MAXVALUE 9999 
   INCREMENT BY 1 
   START WITH 1
   NOCACHE 
   NOORDER 
   NOCYCLE;

INSERT INTO salaris VALUES(salaris_salgrade_seq.NEXTVAL,900, 1500);
INSERT INTO salaris VALUES(salaris_salgrade_seq.NEXTVAL,1501, 3000);
INSERT INTO salaris VALUES(salaris_salgrade_seq.NEXTVAL,3001, 3750);
INSERT INTO salaris VALUES(salaris_salgrade_seq.NEXTVAL,3751, 4500);
INSERT INTO salaris VALUES(salaris_salgrade_seq.NEXTVAL,4501, 5000);
INSERT INTO salaris VALUES(salaris_salgrade_seq.NEXTVAL,5001, 6000);

INSERT INTO type VALUES ('A2','Audi');
INSERT INTO type VALUES ('A2 Diesel','Audi');
INSERT INTO type VALUES ('A3','Audi');
INSERT INTO type VALUES ('A3 Diesel','Audi');
INSERT INTO type VALUES ('A4','Audi');
INSERT INTO type VALUES ('A4 Diesel','Audi');
INSERT INTO type VALUES ('A4 Avant','Audi');
INSERT INTO type VALUES ('A4 Avant Diesel','Audi');
INSERT INTO type VALUES ('S4','Audi');
INSERT INTO type VALUES ('S4 Avant','Audi');
INSERT INTO type VALUES ('A4 Cabriolet','Audi');
INSERT INTO type VALUES ('A4 Cabriolet Diesel','Audi');
INSERT INTO type VALUES ('S4 Cabriolet','Audi');
INSERT INTO type VALUES ('A6','Audi');
INSERT INTO type VALUES ('A6 Diesel','Audi');
INSERT INTO type VALUES ('A6 Avant','Audi');
INSERT INTO type VALUES ('A6 Avant Diesel','Audi');
INSERT INTO type VALUES ('S6','Audi');
INSERT INTO type VALUES ('S6 Avant','Audi');
INSERT INTO type VALUES ('RS6','Audi');
INSERT INTO type VALUES ('RS6 Avant','Audi');
INSERT INTO type VALUES ('All Road Quattro','Audi');
INSERT INTO type VALUES ('All Road Quattro Diesel','Audi');
INSERT INTO type VALUES ('A8','Audi');
INSERT INTO type VALUES ('A8 Diesel','Audi');
INSERT INTO type VALUES ('A8 Long','Audi');
INSERT INTO type VALUES ('A8 Long Diesel','Audi');
INSERT INTO type VALUES ('TT Coupe','Audi');
INSERT INTO type VALUES ('TT Roadster','Audi');
INSERT INTO type VALUES ('Lupo','Volkswagen');
INSERT INTO type VALUES ('Lupo Diesel','Volkswagen');
INSERT INTO type VALUES ('New Beetle','Volkswagen');
INSERT INTO type VALUES ('New Beetle Diesel','Volkswagen');
INSERT INTO type VALUES ('New Beetle Cabrio','Volkswagen');
INSERT INTO type VALUES ('New Beetle Cabrio Diesel','Volkswagen');
INSERT INTO type VALUES ('Polo','Volkswagen');
INSERT INTO type VALUES ('Polo Diesel','Volkswagen');
INSERT INTO type VALUES ('Polo Fun','Volkswagen');
INSERT INTO type VALUES ('Polo Fun Diesel','Volkswagen');
INSERT INTO type VALUES ('Golf','Volkswagen');
INSERT INTO type VALUES ('Golf Diesel','Volkswagen');
INSERT INTO type VALUES ('Golf Variant','Volkswagen');
INSERT INTO type VALUES ('Golf Variant Diesel','Volkswagen');
INSERT INTO type VALUES ('Bora','Volkswagen');
INSERT INTO type VALUES ('Bora Diesel','Volkswagen');
INSERT INTO type VALUES ('Bora Variant Diesel','Volkswagen');
INSERT INTO type VALUES ('Passat','Volkswagen');
INSERT INTO type VALUES ('Passat Diesel','Volkswagen');
INSERT INTO type VALUES ('Passat Variant','Volkswagen');
INSERT INTO type VALUES ('Passat Variant Diesel','Volkswagen');
INSERT INTO type VALUES ('Phaeton','Volkswagen');
INSERT INTO type VALUES ('Phaeton Diesel','Volkswagen');
INSERT INTO type VALUES ('Phaeton LWB','Volkswagen');
INSERT INTO type VALUES ('Phaeton LWB Diesel','Volkswagen');
INSERT INTO type VALUES ('Caddy People','Volkswagen');
INSERT INTO type VALUES ('Caddy People Diesel','Volkswagen');
INSERT INTO type VALUES ('Caddy People 2PLC','Volkswagen');
INSERT INTO type VALUES ('Caddy People 2PLC Diesel','Volkswagen');
INSERT INTO type VALUES ('Touran','Volkswagen');
INSERT INTO type VALUES ('Touran Diesel','Volkswagen');
INSERT INTO type VALUES ('Sharan','Volkswagen');
INSERT INTO type VALUES ('Sharan Diesel','Volkswagen');
INSERT INTO type VALUES ('Multivan','Volkswagen');
INSERT INTO type VALUES ('Multivan Diesel','Volkswagen');
INSERT INTO type VALUES ('Touareg','Volkswagen');
INSERT INTO type VALUES ('Touareg Diesel','Volkswagen');


INSERT INTO auto VALUES ('JKI354','Polo',1998);
INSERT INTO auto VALUES ('UIO654','Golf Diesel',1997);
INSERT INTO auto VALUES ('MPH479','A3',2000);
INSERT INTO auto VALUES ('TGF687','Touareg',2004);
INSERT INTO auto VALUES ('CEG135','Passat',1995);
INSERT INTO auto VALUES ('JKI642','A2',2001);
INSERT INTO auto VALUES ('KID753','A4 Diesel',1991);
INSERT INTO auto VALUES ('AZE563','Golf Variant',2003);
INSERT INTO auto VALUES ('UJD987','Lupo',2003);
INSERT INTO auto VALUES ('IZN765','Bora',2002);
INSERT INTO auto VALUES ('BVC567','A6',2001);
INSERT INTO auto VALUES ('JHG123','New Beetle Cabrio',1998);
INSERT INTO auto VALUES ('GTR678','Caddy People',2004);
INSERT INTO auto VALUES ('XDS753','A6 Avant',2003);
INSERT INTO auto VALUES ('DNO742','Golf',1999);
INSERT INTO auto VALUES ('MDO987','Passat Variant',1999);
INSERT INTO auto VALUES ('FUJ865','A2',2003);
INSERT INTO auto VALUES ('PMO753','Bora Diesel',2000);
INSERT INTO auto VALUES ('IEO876','Polo',1998);
INSERT INTO auto VALUES ('UEN865','A4',2000);
INSERT INTO auto VALUES ('BDY899','A4 Diesel',1999);
INSERT INTO auto VALUES ('UEB765','Golf Diesel',1997);
INSERT INTO auto VALUES ('OIP987','Passat Diesel',2002);
INSERT INTO gemeente (postcode, gemeente) VALUES (9300,'Aalst');
INSERT INTO gemeente (postcode, gemeente) VALUES (9880,'Aalter');
INSERT INTO gemeente (postcode, gemeente) VALUES (6700,'Aarlen');
INSERT INTO gemeente (postcode, gemeente) VALUES (3200,'Aarschot');
INSERT INTO gemeente (postcode, gemeente) VALUES (2630,'Aartselaar');
INSERT INTO gemeente (postcode, gemeente) VALUES (1790,'Affligem');
INSERT INTO gemeente (postcode, gemeente) VALUES (2000,'Antwerpen');
INSERT INTO gemeente (postcode, gemeente) VALUES (4837,'Baelen');
INSERT INTO gemeente (postcode, gemeente) VALUES (6600,'Bastogne');
INSERT INTO gemeente (postcode, gemeente) VALUES (8730,'Beernem');
INSERT INTO gemeente (postcode, gemeente) VALUES (2340,'Beerse');
INSERT INTO gemeente (postcode, gemeente) VALUES (1650,'Beersel');
INSERT INTO gemeente (postcode, gemeente) VALUES (3460,'Bekkevoort');
INSERT INTO gemeente (postcode, gemeente) VALUES (7000,'Bergen');
INSERT INTO gemeente (postcode, gemeente) VALUES (3360,'Bierbeek');
INSERT INTO gemeente (postcode, gemeente) VALUES (4300,'Borgworm');
INSERT INTO gemeente (postcode, gemeente) VALUES (1000,'Brussel');
INSERT INTO gemeente (postcode, gemeente) VALUES (6460,'Chimay');
INSERT INTO gemeente (postcode, gemeente) VALUES (6810,'Chiny');
INSERT INTO gemeente (postcode, gemeente) VALUES (7760,'Celles');
INSERT INTO gemeente (postcode, gemeente) VALUES (8340,'Damme');
INSERT INTO gemeente (postcode, gemeente) VALUES (9800,'Deinze');
INSERT INTO gemeente (postcode, gemeente) VALUES (9200,'Dendermonde');
INSERT INTO gemeente (postcode, gemeente) VALUES (7500,'Doornik');
INSERT INTO gemeente (postcode, gemeente) VALUES (9900,'Eeklo');
INSERT INTO gemeente (postcode, gemeente) VALUES (2650,'Edegem');
INSERT INTO gemeente (postcode, gemeente) VALUES (9420,'Erpe-Mere');
INSERT INTO gemeente (postcode, gemeente) VALUES (3071,'Erps-Kwerps');
INSERT INTO gemeente (postcode, gemeente) VALUES (1140,'Evere');
INSERT INTO gemeente (postcode, gemeente) VALUES (1050,'Elsene');
INSERT INTO gemeente (postcode, gemeente) VALUES (4317,'Faimes');
INSERT INTO gemeente (postcode, gemeente) VALUES (5380,'Fernelmont');
INSERT INTO gemeente (postcode, gemeente) VALUES (1190,'Forrest');
INSERT INTO gemeente (postcode, gemeente) VALUES (2440,'Geel');
INSERT INTO gemeente (postcode, gemeente) VALUES (3450,'Geetbets');
INSERT INTO gemeente (postcode, gemeente) VALUES (8470,'Gistel');
INSERT INTO gemeente (postcode, gemeente) VALUES (2280,'Grobbendonk');
INSERT INTO gemeente (postcode, gemeente) VALUES (3150,'Haacht');
INSERT INTO gemeente (postcode, gemeente) VALUES (3500,'Hasselt');
INSERT INTO gemeente (postcode, gemeente) VALUES (3550, 'Heusden-Zolder');
INSERT INTO gemeente (postcode, gemeente) VALUES (3870,'Heers');
INSERT INTO gemeente (postcode, gemeente) VALUES (3320,'Hoegaarden');
INSERT INTO gemeente (postcode, gemeente) VALUES (3530,'Houthalen-Helchteren');
INSERT INTO gemeente (postcode, gemeente) VALUES (8900,'Ieper');
INSERT INTO gemeente (postcode, gemeente) VALUES (8870,'Izegem');
INSERT INTO gemeente (postcode, gemeente) VALUES (8490,'Jabbeke');
INSERT INTO gemeente (postcode, gemeente) VALUES (1090,'Jette');
INSERT INTO gemeente (postcode, gemeente) VALUES (1910,'Kampenhout');
INSERT INTO gemeente (postcode, gemeente) VALUES (8680,'Koekelare');
INSERT INTO gemeente (postcode, gemeente) VALUES (3000,'Leuven');
INSERT INTO gemeente (postcode, gemeente) VALUES (3920,'Lommel');
INSERT INTO gemeente (postcode, gemeente) VALUES (3680,'Maaseik');
INSERT INTO gemeente (postcode, gemeente) VALUES (1400,'Nijvel');
INSERT INTO gemeente (postcode, gemeente) VALUES (5350,'Ohey');
INSERT INTO gemeente (postcode, gemeente) VALUES (3660,'Opglabbeek');
INSERT INTO gemeente (postcode, gemeente) VALUES (3900,'Overpelt');
INSERT INTO gemeente (postcode, gemeente) VALUES (3990,'Peer');
INSERT INTO gemeente (postcode, gemeente) VALUES (2470,'Retie');
INSERT INTO gemeente (postcode, gemeente) VALUES (9600,'Ronse');
INSERT INTO gemeente (postcode, gemeente) VALUES (3270,'Scherpenheuvel');
INSERT INTO gemeente (postcode, gemeente) VALUES (3390,'Tielt-Winge');
INSERT INTO gemeente (postcode, gemeente) VALUES (3300,'Tienen');
INSERT INTO gemeente (postcode, gemeente) VALUES (1180,'Ukkel');
INSERT INTO gemeente (postcode, gemeente) VALUES (4800,'Verviers');
INSERT INTO gemeente (postcode, gemeente) VALUES (8630,'Veurne');
INSERT INTO gemeente (postcode, gemeente) VALUES (3790,'Voeren');
INSERT INTO gemeente (postcode, gemeente) VALUES (2260,'Westerlo');
INSERT INTO gemeente (postcode, gemeente) VALUES (1930,'Zaventem');

INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3500,TO_DATE('06-dec-2004', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3071,TO_DATE('08-dec-2004', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,2260,TO_DATE('09-dec-2004', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3550,TO_DATE('31-dec-2004', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,8630,TO_DATE('31-dec-2004', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3390,TO_DATE('31-dec-2004', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3790,TO_DATE('31-dec-2004', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3500,TO_DATE('02-jan-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3300,TO_DATE('03-jan-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,1930,TO_DATE('03-jan-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3550,TO_DATE('06-jan-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,8680,TO_DATE('02-jan-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3920,TO_DATE('02-jan-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,1400,TO_DATE('06-jan-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,1090,TO_DATE('05-jan-2005', 'dd-mon-yyyy'));

INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3500,TO_DATE('06-apr-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3071,TO_DATE('08-apr-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,2260,TO_DATE('09-may-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3550,TO_DATE('30-jun-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,8630,TO_DATE('30-jun-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3390,TO_DATE('31-jul-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3790,TO_DATE('31-sep-2005', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3500,TO_DATE('02-jan-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3300,TO_DATE('03-jan-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,1930,TO_DATE('03-feb-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3550,TO_DATE('06-feb-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,8680,TO_DATE('02-apr-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3920,TO_DATE('02-jun-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,1400,TO_DATE('06-sep-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,1090,TO_DATE('05-nov-2006', 'dd-mon-yyyy'));

INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3500,TO_DATE('06-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3071,TO_DATE('08-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3550,TO_DATE('09-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3920,TO_DATE('31-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,2260,TO_DATE('31-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,1090,TO_DATE('31-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3790,TO_DATE('31-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3200,TO_DATE('02-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3300,TO_DATE('03-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,2260,TO_DATE('03-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,1930,TO_DATE('06-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3500,TO_DATE('02-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3320,TO_DATE('02-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,8870,TO_DATE('06-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3320,TO_DATE('05-jan-2007', 'dd-mon-yyyy'));

INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3550,TO_DATE('06-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,4800,TO_DATE('08-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,8630,TO_DATE('09-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3790,TO_DATE('31-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,2260,TO_DATE('31-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,1930,TO_DATE('31-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3300,TO_DATE('31-dec-2006', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3270,TO_DATE('02-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3300,TO_DATE('03-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,1910,TO_DATE('03-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,1400,TO_DATE('06-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,3390,TO_DATE('02-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,2470,TO_DATE('02-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,1180,TO_DATE('06-jan-2007', 'dd-mon-yyyy'));
INSERT INTO flitsen VALUES(flitsen_id_seq.NEXTVAL,8680,TO_DATE('05-jan-2007', 'dd-mon-yyyy'));





INSERT INTO overtredingen VALUES(overtredingen_id_seq.NEXTVAL,'Inbraak',11100,15,'Persoon opgepakt bij een inbraak');
INSERT INTO overtredingen VALUES(overtredingen_id_seq.NEXTVAL,'Winkeldiefstal',200,0,'Persoon opgepakt bij een winkeldiefstal');
INSERT INTO overtredingen VALUES(overtredingen_id_seq.NEXTVAL,'BTW-fraude',65000,24,'Vaststellen van BTW-fraude');
INSERT INTO overtredingen VALUES(overtredingen_id_seq.NEXTVAL,'Snelheidsovertreding 10-20',200,0,'Snelheidsovertreding 20 km/u te snel rijden');
INSERT INTO overtredingen VALUES(overtredingen_id_seq.NEXTVAL,'Snelheidsovertreding 21-30',320,0,'Snelheidsovertreding 30 km/u te snel rijden');
INSERT INTO overtredingen VALUES(overtredingen_id_seq.NEXTVAL,'Snelheidsovertreding 31-40',456,0,'Snelheidsovertreding 40 km/u te snel rijden');
INSERT INTO overtredingen VALUES(overtredingen_id_seq.NEXTVAL,'Snelheidsovertreding >50',790,0,'Snelheidsovertreding > 50 km/u te snel rijden, intrekken van rijbewijs');
INSERT INTO overtredingen VALUES(overtredingen_id_seq.NEXTVAL,'Openbaar dronkenschap',150,0,'1 nacht cel');
INSERT INTO overtredingen VALUES(overtredingen_id_seq.NEXTVAL,'Vernielen van eigendom',310,0,'Terugbetaling van aangebrachte schade');


INSERT INTO departement VALUES(departement_id_seq.NEXTVAL,'Commisariaat');
INSERT INTO departement VALUES(departement_id_seq.NEXTVAL,'Administratie');
INSERT INTO departement VALUES(departement_id_seq.NEXTVAL,'Gevangenis');


INSERT INTO graad VALUES(graad_id_seq.NEXTVAL,'Stadspolitie');
INSERT INTO graad VALUES(graad_id_seq.NEXTVAL,'Wijkagent');
INSERT INTO graad VALUES(graad_id_seq.NEXTVAL,'Inspecteur');
INSERT INTO graad VALUES(graad_id_seq.NEXTVAL,'Hoofd-Inspecteur');
INSERT INTO graad VALUES(graad_id_seq.NEXTVAL,'Commissaris');
INSERT INTO graad VALUES(graad_id_seq.NEXTVAL,'Hoofdcommissaris');


INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Motmans','Rob','Sint-Maartenplein',36,1930,'011/313461','0496/101010','rob.motmans@politie.be','MPH479',1,1,2200,TO_DATE('12-sep-1998', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Klawitter','Nils','Zonneweeldelaan',17,3270,'089/445566','0496/111335','nils.klawitter@politie.be','IZN765',5,2,4552,TO_DATE('12-aug-1998', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Kenes','Jules','Statiestraat',74,3390,'016/236485','0496/163335','jules.kenes@politie.be','JKI354',1,2,2300,TO_DATE('12-nov-1998', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Franssen','Fons','Saliestraat',76,3390,'016/652485','0497/165335','fons.franssen@politie.be','BVC567',1,2,1950,TO_DATE('12-nov-1998', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Huisjes','Albert','Bloemenstraat',76,3500,'011/652655','0497/163235','albert.huisjes@politie.be',NULL,2,1,2621,TO_DATE('09-nov-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Willems','Bjorn','Vaarnstraat',25,3270,'082/636485','0497/658435','bjorn.willems@politie.be',NULL,2,1,2841,TO_DATE('09-apr-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Waterman','Wim','peertjesstraat',76,1180,'065/652475','0494/525335','wim.waterman@politie.be',NULL,2,1,2354,TO_DATE('13-feb-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Janssens','Herman','Tulpenstraat',76,3270,'016/652254','0497/165475','herman.janssens@politie.be',NULL,2,1,1987,TO_DATE('15-dec-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Klimop','Fine','Meesstraat',76,3900,'018/652485','0475/165335','fine.klimop@politie.be','UJD987',2,1,1999,TO_DATE('09-nov-1998', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Daenen','Jef','Jaagpad',2,1400,'062/652485','0494/165335','jef.daenen@politie.be',NULL,2,1,2002,TO_DATE('09-nov-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Tilkens','Luciene','P.Ballingsstraat',76,3550,'011/652635','0497/162135','luciene.tilkes@politie.be','UIO654',2,1,2698,TO_DATE('09-jun-1997', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Claes','Margaret','Kolenstraat',76,3300,'016/635485','0497/635335','margaret.claes@politie.be',NULL,2,1,2541,TO_DATE('26-nov-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Kuppens','Johan','Madeliefstraat',62,3530,'011/659885','0494/145335','johan.kuppens@politie.be','TGF687',2,1,2365,TO_DATE('09-nov-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Beervoets','Kris','Dorpsstraat',42,3530,'011/652885','0494/146935','kris.beervoets@politie.be','OIP987',6,1,5021,TO_DATE('17-apr-1989', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Berden','Johan','Blerebergstraat',22,3550,'011/329885','0499/125335','johan.berden@politie.be','CEG135',2,1,2145,TO_DATE('23-nov-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Spaelt','Annelies','Grensstraat',45,9600,'052/659885','0495/145335','annelies.spaelt@politie.be',NULL,1,2,3001,TO_DATE('26-nov-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Vanneste','Truus','Lievensstraat',12,3990,'011/664885','0494/145485','truus.vanneste@politie.be',NULL,1,2,1100,TO_DATE('02-feb-2004', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Goedeman','Vincent','Kerkstraat',62,2470,'015/659885','0494/169335','vincent.goedeman@politie.be','KID753',1,2,1852,TO_DATE('09-jan-1997', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Verstreken','John','Koelstraat',65,3680,'011/655485','0494/198335','john.verstreken@politie.be',NULL,5,2,4100,TO_DATE('15-jul-2000', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Janssens','Janina','Tuinstraat',98,3870,'016/659885','0494/187335','janina.janssens@politie.be','AZE563',2,1,2145,TO_DATE('09-nov-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Heersel','Piet','Watermanstraat',48,3320,'018/659885','0472/145335','piet.heersel@politie.be','XDS753',2,1,1987,TO_DATE('23-dec-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Borders','Tim','Dorpsstraat',62,4300,'012/659885','0494/146535','tim.borders@politie.be','DNO742',1,1,2854,TO_DATE('09-jan-1987', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Terriers','Steven','Sporkstraat',65,5350,'065/659885','0494/145985','steven.terriers@politie.be',NULL,1,2,999,TO_DATE('09-nov-2001', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Teerain','Sven','Sportstraat',62,8900,'052/652885','0494/144135','sven.teerain@politie.be',NULL,1,2, 1300,TO_DATE('09-dec-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Bergen','Koen','Landweg',69,8900,'052/623885','0494/142535','koen.bergen@politie.be',NULL,1,2,1625,TO_DATE('07-apr-1995', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Bertels','Bert','Koekoeksstraat',62,2260,'015/652885','0494/142535','bert.bertels@politie.be',NULL,1,2,1587,TO_DATE('11-apr-1999', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'De Backer','Birgit','Merelstraat',62,3660,'016/655285','0475/144135','birgit.debacker@politie.be',NULL,1,2,1458,TO_DATE('16-dec-1998', 'dd-mon-yyyy'));
INSERT INTO personeel VALUES(personeel_id_seq.NEXTVAL,'Charlo','Jan','Veldstraat',22,4300,'012/652885','0494/156135','jan.charlo@politie.be',NULL,1,2,1698,TO_DATE('09-jan-1999', 'dd-mon-yyyy'));

INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Zontrop','Pascal','Filmlaan',15,3500,'011/334455',3,4,TO_DATE('22-jan-2000', 'DD-MON-YYYY'),TO_DATE('00:23', 'hh24:mi'),3550,'Roekeloos rijden');
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Vos','Dany','Herentstraat', 13,3500,'011/378412',6,2,TO_DATE('24-jan-2000', 'DD-MON-YYYY'),TO_DATE('02:24', 'hh24:mi'),3550,'Inbraak');
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Jaarmans','Frans','Kielstraat',20,3530,'011/398455',8,5,TO_DATE('01-jan-2002', 'DD-MON-YYYY'),TO_DATE('04:24', 'hh24:mi'),3660,'Roekeloos rijden');
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Vaes','David','Bergstraat', 25,2470,'015/378455',10,2,TO_DATE('24-dec-2002', 'DD-MON-YYYY'),TO_DATE('00:54', 'hh24:mi'),2470,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Darios','Jan','Ketelstraat', 23,1400,'026/323455',19,2,TO_DATE('24-jan-2001', 'DD-MON-YYYY'),TO_DATE('22:24', 'hh24:mi'),1400,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Volders','Stijn','Smeetsstraat', 65,3270,'011/365455',9,2,TO_DATE('24-jan-2000', 'DD-MON-YYYY'),TO_DATE('20:24', 'hh24:mi'),3270,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Janssens','Vanessa','Koopliedenstraat', 65,1000,'02/525455',13,5,TO_DATE('24-apr-2001', 'DD-MON-YYYY'),TO_DATE('23:51', 'hh24:mi'),1180,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Jacobs','Arthur','Merlestraat', 59,1910,'091/525455',12,5,TO_DATE('19-apr-2001', 'DD-MON-YYYY'),TO_DATE('21:51', 'hh24:mi'),1180,'Roekeloos rijden');
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Jans','Xander','Veldekensstraat', 84,1000,'011/525895',13,5,TO_DATE('11-nov-2002', 'DD-MON-YYYY'),TO_DATE('23:51', 'hh24:mi'),3500,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Giesberts','Laura','Temaerestraat', 65, 3550,'011/525455',13,5,TO_DATE('18-dec-2001', 'DD-MON-YYYY'),TO_DATE('22:51', 'hh24:mi'),3530,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Heline','Julie','Martestraat', 15, 3900,'011/525455',13,5,TO_DATE('24-apr-2001', 'DD-MON-YYYY'),TO_DATE('22:49', 'hh24:mi'),3270,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Overzee','Joerie','Meerstraat', 25, 1000,'02/5225455',20,8,TO_DATE('23-feb-2001', 'DD-MON-YYYY'),TO_DATE('00:31', 'hh24:mi'),1180,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'De Berde','Francine','Jachtlaan', 26 ,3660,'011/525855',13,6,TO_DATE('12-apr-2002', 'DD-MON-YYYY'),TO_DATE('23:51', 'hh24:mi'),3660,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Zetterberg','Tim','prinsenlaan', 65 ,3390,'011/525455',13,5,TO_DATE('24-jul-2003', 'DD-MON-YYYY'),TO_DATE('23:51', 'hh24:mi'),2440,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Valenberg','Tom','Neerstraat', 43,4317,'026/525455',18,4,TO_DATE('24-jun-2002', 'DD-MON-YYYY'),TO_DATE('16:51', 'hh24:mi'),4317,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Prinsent','Louis','Vaartstraat', 265,3270,'016/556455',27, 5,TO_DATE('06-dec-2004', 'DD-MON-YYYY'),TO_DATE('20:51', 'hh24:mi'),3500,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Wevelaar','Tom','Halensebaan', 25,8870,'051/525455',27,5,TO_DATE('06-dec-2004', 'DD-MON-YYYY'),TO_DATE('22:01', 'hh24:mi'),3500,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Hermans','Annemiek','Gerartstraat', 32,3870,'018/525455',27,4,TO_DATE('06-dec-2004', 'DD-MON-YYYY'),TO_DATE('23:51', 'hh24:mi'),3500,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Graadsberg','Guy','Gistelsesteenweg', 26,8490,'053/525455',27,5,TO_DATE('06-dec-2001', 'DD-MON-YYYY'),TO_DATE('23:53', 'hh24:mi'),3500,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Bossens','Bert','Jeugdlaan', 2,8900,'019/528955',22,5,TO_DATE('08-dec-2004', 'DD-MON-YYYY'),TO_DATE('18:51', 'hh24:mi'),3071,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Naturalis','Hermelien','Dreuzelstraat', 34,3660,'011/525265',22,5,TO_DATE('08-dec-2004', 'DD-MON-YYYY'),TO_DATE('19:51', 'hh24:mi'),3071,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Vaselien','Wouter','Hoge Eik', 4,2470,'015/656555',22,5,TO_DATE('08-dec-2004', 'DD-MON-YYYY'),TO_DATE('20:41', 'hh24:mi'),3071,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Kleinst','Olivier','Waterweg', 2,5350,'054/525455',22,5,TO_DATE('08-dec-2004', 'DD-MON-YYYY'),TO_DATE('20:51', 'hh24:mi'),3071,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Gheist','Christophe','Broekstraat', 54,2260,'015/525455',18,5,TO_DATE('09-dec-2004', 'DD-MON-YYYY'),TO_DATE('09:51', 'hh24:mi'),2260,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Davidson','David','Hieligstraat', 54,1400,'041/525455',18,5,TO_DATE('09-dec-2004', 'DD-MON-YYYY'),TO_DATE('10:51', 'hh24:mi'),2260,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Stratenhof','Sandrine','Antwerpse steenweg', 326,3000,'03/525455',18,5,TO_DATE('09-dec-2004', 'DD-MON-YYYY'),TO_DATE('11:59', 'hh24:mi'),2260,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Xerios','Katrien','Vesteweg', 23,3500,'011/525555',10,4,TO_DATE('31-dec-2004', 'DD-MON-YYYY'),TO_DATE('22:51', 'hh24:mi'),3550,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Postels','Gert','Postelstraat', 65,3530,'011/525455',22,5,TO_DATE('31-dec-2004', 'DD-MON-YYYY'),TO_DATE('23:01', 'hh24:mi'),3550,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Kristofels','Jean-Fran�ois','Walenweg', 45,3990,'016/556455',7,5,TO_DATE('31-dec-2004', 'DD-MON-YYYY'),TO_DATE('23:51', 'hh24:mi'),8630,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Trekhas','Jasmien','Trekkersvest', 25,9600,'045/525455',7,5,TO_DATE('31-dec-2004', 'DD-MON-YYYY'),TO_DATE('23:52', 'hh24:mi'),8630,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Vastrecht','Nicky','Hoosweg', 2,8470,'050/525455',15,4,TO_DATE('31-dec-2004', 'DD-MON-YYYY'),TO_DATE('21:51', 'hh24:mi'),3790,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Hertogen','Hans','Kloosterweg', 26,3320,'028/525455',15,5,TO_DATE('31-dec-2004', 'DD-MON-YYYY'),TO_DATE('22:31', 'hh24:mi'),3790,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Valders','Valere','Hereweg', 23,3660,'011/525455',22,5,TO_DATE('02-jan-2005', 'DD-MON-YYYY'),TO_DATE('20:51', 'hh24:mi'),3500,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Janssen','Jan','Jamersstraat', 34,2470,'015/525485',11,5,TO_DATE('03-jan-2005', 'DD-MON-YYYY'),TO_DATE('19:51', 'hh24:mi'),3300,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Herels','Herman','Kraamstraat', 58,2260,'015/599455',28,5,TO_DATE('03-jan-2005', 'DD-MON-YYYY'),TO_DATE('18:51', 'hh24:mi'),1930,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Hemerlijn','Tibo','Seeuwweg', 45,3550,'011/525455',12,5,TO_DATE('06-jan-2005', 'DD-MON-YYYY'),TO_DATE('09:23', 'hh24:mi'),3550,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Iepers','Yocelyn','zemstweg', 89,1910,'04/525455',22,5,TO_DATE('02-jan-2005', 'DD-MON-YYYY'),TO_DATE('07:51', 'hh24:mi'),8680,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Tasjes','Andrea','Bekkenstraat', 65, 4300,'050/526555',6,5,TO_DATE('06-jan-2005', 'DD-MON-YYYY'),TO_DATE('07:41', 'hh24:mi'),1400,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Servaes','Jan','Doelenlaan', 62, 3550,'011/426555',4,9,TO_DATE('01-jan-2005', 'DD-MON-YYYY'),TO_DATE('00:41', 'hh24:mi'),3500,'liep waggelend op de witte lijn');


INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Kleppers','Pascal','Filmlaan',15,3500,'011/334455',3,4,TO_DATE('06-dec-2006', 'DD-MON-YYYY'),TO_DATE('00:23', 'hh24:mi'),3500,'Roekeloos rijden');
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'De Haan','Dany','Herentstraat', 13,3500,'011/378412',6,5,TO_DATE('06-dec-2006', 'DD-MON-YYYY'),TO_DATE('02:24', 'hh24:mi'),3500,'in bebouwde kom');
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Jaarkools','Frans','Kielstraat',20,3530,'011/398455',8,5,TO_DATE('31-dec-2006', 'DD-MON-YYYY'),TO_DATE('04:24', 'hh24:mi'),1090,'Roekeloos rijden');
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Varinello','David','Bergstraat', 25,2470,'015/378455',10,6,TO_DATE('31-dec-2006', 'DD-MON-YYYY'),TO_DATE('00:54', 'hh24:mi'),1090,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Reynders','Jan','Ketelstraat', 23,1400,'026/323455',19,4,TO_DATE('08-dec-2006', 'DD-MON-YYYY'),TO_DATE('22:24', 'hh24:mi'),3071,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Dirkmans','Stijn','Smeetsstraat', 65,3270,'011/365455',9,5,TO_DATE('08-dec-2006', 'DD-MON-YYYY'),TO_DATE('20:24', 'hh24:mi'),3071,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Smith','Vanessa','Koopliedenstraat', 65,1000,'02/525455',13,5,TO_DATE('07-jan-2007', 'DD-MON-YYYY'),TO_DATE('23:51', 'hh24:mi'),3200,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Jahorsen','Arthur','Merlestraat', 59,1910,'091/525455',12,5,TO_DATE('02-jan-2007', 'DD-MON-YYYY'),TO_DATE('21:51', 'hh24:mi'),3200,'Roekeloos rijden');
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Eijbergs','Xander','Veldekensstraat', 84,1000,'011/525895',13,5,TO_DATE('02-jan-2007', 'DD-MON-YYYY'),TO_DATE('23:51', 'hh24:mi'),3200,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Bosmans','Laura','Temaerestraat', 65, 3550,'011/525455',13,5,TO_DATE('02-jan-2007', 'DD-MON-YYYY'),TO_DATE('22:51', 'hh24:mi'),3200,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Jordaans','Julie','Martestraat', 15, 3900,'011/525455',13,5,TO_DATE('03-jan-2007', 'DD-MON-YYYY'),TO_DATE('22:49', 'hh24:mi'),3300,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Williams','Joerie','Meerstraat', 25, 1000,'02/5225455',20,6,TO_DATE('03-jan-2007', 'DD-MON-YYYY'),TO_DATE('00:31', 'hh24:mi'),3300,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Jornaal','Francine','Jachtlaan', 26 ,3660,'011/525855',13,6,TO_DATE('05-jan-2007', 'DD-MON-YYYY'),TO_DATE('23:51', 'hh24:mi'),3320,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Papeldar','Tim','prinsenlaan', 65 ,3390,'011/525455',13,5,TO_DATE('05-jan-2007', 'DD-MON-YYYY'),TO_DATE('23:51', 'hh24:mi'),3320,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Simons','Tom','Neerstraat', 43,4317,'026/525455',18,4,TO_DATE('05-jan-2007', 'DD-MON-YYYY'),TO_DATE('16:51', 'hh24:mi'),3320,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Maasmans','Louis','Vaartstraat', 265,3270,'016/556455',27, 5,TO_DATE('06-jan-2007', 'DD-MON-YYYY'),TO_DATE('20:51', 'hh24:mi'),8870,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Jochens','Tom','Halensebaan', 25,8870,'051/525455',27,5,TO_DATE('06-jan-2007', 'DD-MON-YYYY'),TO_DATE('22:01', 'hh24:mi'),8870,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Ceyssens','Annemiek','Gerartstraat', 32,3870,'018/525455',27,4,TO_DATE('06-jan-2007', 'DD-MON-YYYY'),TO_DATE('23:51', 'hh24:mi'),8870,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Soer','Guy','Gistelsesteenweg', 26,8490,'053/525455',27,5,TO_DATE('03-feb-2006', 'DD-MON-YYYY'),TO_DATE('23:53', 'hh24:mi'),1930,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Kapres','Bert','Jeugdlaan', 2,8900,'019/528955',22,5,TO_DATE('03-feb-2006', 'DD-MON-YYYY'),TO_DATE('18:51', 'hh24:mi'),1930,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Cromaars','Hermelien','Dreuzelstraat', 34,3660,'011/525265',22,5,TO_DATE('03-feb-2006', 'DD-MON-YYYY'),TO_DATE('19:51', 'hh24:mi'),1930,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Kloothars','Wouter','Hoge Eik', 4,2470,'015/656555',22,5,TO_DATE('02-apr-2006', 'DD-MON-YYYY'),TO_DATE('20:41', 'hh24:mi'),8680,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Yanniers','Olivier','Waterweg', 2,5350,'054/525455',22,5,TO_DATE('02-apr-2006', 'DD-MON-YYYY'),TO_DATE('20:51', 'hh24:mi'),8680,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Driessens','Christophe','Broekstraat', 54,2260,'015/525455',18,5,TO_DATE('02-apr-2006', 'DD-MON-YYYY'),TO_DATE('09:51', 'hh24:mi'),8680,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Dior','David','Hieligstraat', 54,1400,'041/525455',18,5,TO_DATE('06-apr-2005', 'DD-MON-YYYY'),TO_DATE('10:51', 'hh24:mi'),3500,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Walput','Sandrine','Antwerpse steenweg', 326,3000,'03/525455',18,5,TO_DATE('06-apr-2005', 'DD-MON-YYYY'),TO_DATE('11:59', 'hh24:mi'),3500,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Kinet','Katrien','Vesteweg', 23,3500,'011/525555',10,4,TO_DATE('06-apr-2005', 'DD-MON-YYYY'),TO_DATE('22:51', 'hh24:mi'),3500,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Lepot','Gert','Postelstraat', 65,3530,'011/525455',22,5,TO_DATE('08-apr-2005', 'DD-MON-YYYY'),TO_DATE('23:01', 'hh24:mi'),3071,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Wieers','Jean-Fran�ois','Walenweg', 45,3990,'016/556455',7,5,TO_DATE('08-apr-2005', 'DD-MON-YYYY'),TO_DATE('23:51', 'hh24:mi'),3071,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Cimino','Jasmien','Trekkersvest', 25,9600,'045/525455',7,5,TO_DATE('08-apr-2005', 'DD-MON-YYYY'),TO_DATE('23:52', 'hh24:mi'),3071,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Joosten','Nicky','Hoosweg', 2,8470,'050/525455',15,4,TO_DATE('09-may-2005', 'DD-MON-YYYY'),TO_DATE('21:51', 'hh24:mi'),2260,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Kinders','Hans','Kloosterweg', 26,3320,'028/525455',15,5,TO_DATE('09-may-2005', 'DD-MON-YYYY'),TO_DATE('22:31', 'hh24:mi'),2260,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'De Neuter','Valere','Hereweg', 23,3660,'011/525455',22,5,TO_DATE('09-may-2005', 'DD-MON-YYYY'),TO_DATE('20:51', 'hh24:mi'),2260,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Van Stabroek','Jan','Jamersstraat', 34,2470,'015/525485',11,5,TO_DATE('30-jun-2005', 'DD-MON-YYYY'),TO_DATE('19:51', 'hh24:mi'),3550,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Hemelsaart','Herman','Kraamstraat', 58,2260,'015/599455',28,5,TO_DATE('30-jun-2005', 'DD-MON-YYYY'),TO_DATE('18:51', 'hh24:mi'),3550,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Vandebroek','Tibo','Seeuwweg', 45,3550,'011/525455',12,5,TO_DATE('30-jun-2005', 'DD-MON-YYYY'),TO_DATE('09:23', 'hh24:mi'),3550,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Van Poort','Yocelyn','zemstweg', 89,1910,'04/525455',22,5,TO_DATE('30-jun-2005', 'DD-MON-YYYY'),TO_DATE('07:51', 'hh24:mi'),8630,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Willems','Andrea','Bekkenstraat', 65, 4300,'050/526555',6,5,TO_DATE('30-jun-2005', 'DD-MON-YYYY'),TO_DATE('07:41', 'hh24:mi'),8630,NULL);
INSERT INTO pv VALUES(pv_id_seq.NEXTVAL,'Broos','Jan','Doelenlaan', 62, 3550,'011/426555',4,9,TO_DATE('01-jan-2005', 'DD-MON-YYYY'),TO_DATE('00:41', 'hh24:mi'),3500,'liep waggelend op de witte lijn');







commit;


